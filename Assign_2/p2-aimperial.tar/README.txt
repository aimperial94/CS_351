Name: Andres Imperial
Email: andres.imperial@csu.fullerton.edu
Language: c++


How to execute:
	Compile the program using the Makefile.
	Then start executing recv by using:
	./recv
	Then start executing sender by using:
	./sender <fileName>
	Use the name of the file you wish to transfer.

Extra Credit: 
	Not Implemented

Notes:
	N/A
